const API_KEY = '2b4047f3271c507a75afaeb60ac21474';
const form = document.getElementById('weather-form');
const cityInput = document.getElementById('city');
const currentWeatherDiv = document.getElementById('currentWeather');
const forecastCardsDiv = document.getElementById('forecastCards');
const chartCanvas = document.getElementById('weatherChart');
const unitToggle = document.getElementById('unitToggle');
const loader = document.getElementById('loader');

let tempUnit = 'metric'; // default Celsius
let weatherChart; // to hold Chart.js instance

async function fetchWeather(city) {
  const url = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=${tempUnit}&appid=${API_KEY}`;
  loader.classList.remove('hidden');
  try {
    const res = await fetch(url);
    const data = await res.json();
    if (data.cod !== '200') throw new Error(data.message);
    return data;
  } catch (err) {
    alert('Failed to fetch weather: ' + err.message);
    return null;
  } finally {
    loader.classList.add('hidden');
  }
}

function displayCurrentWeather(data) {
  const now = data.list[0];
  currentWeatherDiv.innerHTML = `
    <h2>${data.city.name}, ${data.city.country}</h2>
    <img src="https://openweathermap.org/img/wn/${now.weather[0].icon}@2x.png" alt="${now.weather[0].description}" />
    <p>${now.weather[0].description}</p>
    <p>🌡️ Temp: ${now.main.temp}°${tempUnit === 'metric' ? 'C' : 'F'}</p>
    <p>💧 Humidity: ${now.main.humidity}%</p>
    <p>🌬️ Wind: ${now.wind.speed} ${tempUnit === 'metric' ? 'm/s' : 'mph'}</p>
  `;
}

function displayForecast(data) {
  const daily = {};
  data.list.forEach(entry => {
    const date = entry.dt_txt.split(' ')[0];
    if (!daily[date]) daily[date] = [];
    daily[date].push(entry);
  });

  forecastCardsDiv.innerHTML = '';
  Object.keys(daily).slice(0, 5).forEach(date => {
    const dayData = daily[date];
    const avgTemp = (dayData.reduce((sum, item) => sum + item.main.temp, 0) / dayData.length).toFixed(1);
    const icon = dayData[0].weather[0].icon;
    forecastCardsDiv.innerHTML += `
      <div class="card">
        <h4>${new Date(date).toDateString()}</h4>
        <img src="https://openweathermap.org/img/wn/${icon}.png" alt="weather icon" />
        <p>${avgTemp}°${tempUnit === 'metric' ? 'C' : 'F'}</p>
      </div>
    `;
  });
}

function renderChart(data) {
  const temps = data.list.map(e => e.main.temp);
  const times = data.list.map(e => e.dt_txt.split(' ')[1].slice(0, 5));

  if (weatherChart) weatherChart.destroy();

  weatherChart = new Chart(chartCanvas.getContext('2d'), {
    type: 'line',
    data: {
      labels: times,
      datasets: [{
        label: `Temperature (${tempUnit === 'metric' ? '°C' : '°F'})`,
        data: temps,
        borderColor: '#0072ff',
        backgroundColor: 'rgba(0, 114, 255, 0.2)',
        fill: true,
        tension: 0.3,
        pointRadius: 3,
      }]
    },
    options: {
      responsive: true,
      scales: {
        x: {
          ticks: { color: '#333' }
        },
        y: {
          ticks: { color: '#333' }
        }
      },
      plugins: {
        legend: {
          labels: {
            color: '#333',
            font: {
              size: 14,
              weight: 'bold'
            }
          }
        }
      }
    }
  });
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const city = cityInput.value.trim();
  if (!city) return;
  const weatherData = await fetchWeather(city);
  if (weatherData) {
    displayCurrentWeather(weatherData);
    displayForecast(weatherData);
    renderChart(weatherData);
  }
});

unitToggle.addEventListener('change', () => {
  tempUnit = unitToggle.checked ? 'imperial' : 'metric';
  if (cityInput.value.trim()) {
    // Refresh weather data on unit change if city input exists
    form.dispatchEvent(new Event('submit'));
  }
});
