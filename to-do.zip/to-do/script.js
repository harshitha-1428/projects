// Task data and state
let tasks = [];
let currentFilter = 'all';
let editingTaskId = null;

// DOM elements
const taskInput = document.getElementById('taskInput');
const addBtn = document.getElementById('addBtn');
const tasksList = document.getElementById('tasksList');
const emptyState = document.getElementById('emptyState');
const taskCounter = document.getElementById('taskCounter');
const totalStats = document.getElementById('totalStats');
const footer = document.getElementById('footer');
const filterBtns = document.querySelectorAll('.filter-btn');

// Load tasks from localStorage on page load
function loadTasks() {
    const savedTasks = localStorage.getItem('todoTasks');
    if (savedTasks) {
        tasks = JSON.parse(savedTasks);
    }
}

// Save tasks to localStorage
function saveTasks() {
    localStorage.setItem('todoTasks', JSON.stringify(tasks));
}

// Generate unique ID
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Add new task
function addTask() {
    const text = taskInput.value.trim();
    if (text) {
        const task = {
            id: generateId(),
            text: text,
            completed: false,
            createdAt: new Date().toISOString()
        };
        tasks.unshift(task);
        taskInput.value = '';
        saveTasks();
        renderTasks();
    }
}

// Toggle task completion
function toggleTask(id) {
    const task = tasks.find(t => t.id === id);
    if (task) {
        task.completed = !task.completed;
        saveTasks();
        renderTasks();
    }
}

// Delete task
function deleteTask(id) {
    tasks = tasks.filter(t => t.id !== id);
    saveTasks();
    renderTasks();
}

// Start editing task
function startEditing(id) {
    editingTaskId = id;
    renderTasks();
    
    // Focus on the edit input
    const editInput = document.querySelector(`[data-task-id="${id}"] .task-edit-input`);
    if (editInput) {
        editInput.focus();
        editInput.select();
    }
}

// Save edit
function saveEdit(id, newText) {
    const task = tasks.find(t => t.id === id);
    if (task && newText.trim()) {
        task.text = newText.trim();
        editingTaskId = null;
        saveTasks();
        renderTasks();
    }
}

// Cancel edit
function cancelEdit() {
    editingTaskId = null;
    renderTasks();
}

// Filter tasks
function getFilteredTasks() {
    if (currentFilter === 'active') {
        return tasks.filter(task => !task.completed);
    } else if (currentFilter === 'completed') {
        return tasks.filter(task => task.completed);
    }
    return tasks;
}

// Update task counter and stats
function updateStats() {
    const activeTasks = tasks.filter(task => !task.completed).length;
    const completedTasks = tasks.length - activeTasks;
    
    taskCounter.textContent = `${activeTasks} ${activeTasks === 1 ? 'task' : 'tasks'} remaining`;
    totalStats.textContent = `Total: ${tasks.length} tasks • Completed: ${completedTasks}`;
    
    footer.style.display = tasks.length > 0 ? 'block' : 'none';
}

// Render tasks
function renderTasks() {
    const filteredTasks = getFilteredTasks();
    
    // Clear tasks list
    tasksList.innerHTML = '';
    
    if (filteredTasks.length === 0) {
        let emptyMessage = "No tasks yet. Add one above!";
        if (currentFilter === 'completed' && tasks.length > 0) {
            emptyMessage = "No completed tasks yet";
        } else if (currentFilter === 'active' && tasks.length > 0) {
            emptyMessage = "All tasks completed! 🎉";
        }
        
        const emptyDiv = document.createElement('div');
        emptyDiv.className = 'empty-state';
        emptyDiv.textContent = emptyMessage;
        tasksList.appendChild(emptyDiv);
    } else {
        filteredTasks.forEach(task => {
            const taskElement = createTaskElement(task);
            tasksList.appendChild(taskElement);
        });
    }
    
    updateStats();
}

// Create task element
function createTaskElement(task) {
    const isEditing = editingTaskId === task.id;
    
    const taskDiv = document.createElement('div');
    taskDiv.className = `task-item ${task.completed ? 'completed' : ''}`;
    taskDiv.setAttribute('data-task-id', task.id);
    
    taskDiv.innerHTML = `
        <div class="task-content">
            <div class="task-checkbox ${task.completed ? 'checked' : ''}" onclick="toggleTask('${task.id}')"></div>
            <span class="task-text ${task.completed ? 'completed' : ''} ${isEditing ? 'editing' : ''}">${task.text}</span>
            <input type="text" class="task-edit-input" value="${task.text}" ${isEditing ? 'style="display: block;"' : ''} 
                   onblur="saveEdit('${task.id}', this.value)" 
                   onkeydown="handleEditKeydown(event, '${task.id}', this.value)">
            ${!isEditing ? `
                <div class="task-actions">
                    <button class="task-btn" onclick="startEditing('${task.id}')" title="Edit">✏️</button>
                    <button class="task-btn delete" onclick="deleteTask('${task.id}')" title="Delete">🗑️</button>
                </div>
            ` : ''}
        </div>
    `;
    
    return taskDiv;
}

// Handle edit input keydown
function handleEditKeydown(event, id, value) {
    if (event.key === 'Enter') {
        saveEdit(id, value);
    } else if (event.key === 'Escape') {
        cancelEdit();
    }
}

// Set filter
function setFilter(filter) {
    currentFilter = filter;
    
    // Update filter button styles
    filterBtns.forEach(btn => {
        if (btn.dataset.filter === filter) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
    
    renderTasks();
}

// Event listeners
addBtn.addEventListener('click', addTask);

taskInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        addTask();
    }
});

filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        setFilter(btn.dataset.filter);
    });
});

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    loadTasks();
    renderTasks();
});

// Make functions global for onclick handlers
window.toggleTask = toggleTask;
window.deleteTask = deleteTask;
window.startEditing = startEditing;
window.saveEdit = saveEdit;
window.handleEditKeydown = handleEditKeydown;